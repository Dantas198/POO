package contribuintes;

public interface BeneficioFiscal {
	public double reducaoImposto();
}
