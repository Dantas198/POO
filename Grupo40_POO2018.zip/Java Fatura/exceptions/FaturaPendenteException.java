package exceptions;

 

public class FaturaPendenteException extends Exception {
	
	public FaturaPendenteException(String m) {
		super(m);
	}
	
	public FaturaPendenteException() {
		super();
	}
}
