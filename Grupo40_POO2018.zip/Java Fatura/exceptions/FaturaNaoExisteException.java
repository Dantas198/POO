package exceptions;

 

public class FaturaNaoExisteException extends Exception {
	public FaturaNaoExisteException(String m) {
		super(m);
	}
	
	public FaturaNaoExisteException() {
		super();
	}
}
