package exceptions;

public class UserdidntSendInput extends Exception {
	
	public UserdidntSendInput(String m) {
		super(m);
	}
	
	public UserdidntSendInput() {
		super();
	}
}
