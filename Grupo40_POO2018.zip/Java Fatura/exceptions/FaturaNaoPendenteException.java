package exceptions;

 

public class FaturaNaoPendenteException extends Exception {
	
	public FaturaNaoPendenteException(String m) {
		super(m);
	}
	
	public FaturaNaoPendenteException() {
		super();
	}
}
