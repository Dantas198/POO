package exceptions;

 

public class ContribuinteNaoIndividualException extends Exception {
	public ContribuinteNaoIndividualException(String m) {
		super(m);
	}
	
	public ContribuinteNaoIndividualException() {
		super();
	}
}
