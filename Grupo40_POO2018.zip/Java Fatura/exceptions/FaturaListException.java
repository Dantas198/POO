package exceptions;


/**
 * Write a description of class FaturaListException here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class FaturaListException extends Exception
{
   public FaturaListException(String m) {
        super(m);
   }
    
   public FaturaListException() {
        super();
   }
}
